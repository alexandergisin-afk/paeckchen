import { expect, test } from "@playwright/test";
import { mockSupabase, watchProblems } from "./mock";

test("Gäste sehen die Liste ohne Anmeldung, filtern und reservieren mit Namen", async ({ page }) => {
  const problems = watchProblems(page);
  const calls = await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await expect(page.getByRole("heading", { name: "Emmas 9. Geburtstag" })).toBeVisible();
  await expect(page.getByText("Anmelde-Mail schicken")).toHaveCount(0);

  // Nichts ragt über den Bildschirmrand
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

  // Preisfilter
  await page.getByRole("button", { name: "bis 20 €" }).click();
  await expect(page.locator(".gcard .gtitle", { hasText: "Kinderfahrrad" })).toHaveCount(0);
  await page.getByRole("button", { name: "Alle", exact: true }).click();

  // Reservieren: ohne Namen geht es nicht
  await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
  await page.getByRole("button", { name: "Jetzt reservieren" }).click();
  expect(calls.rpc).not.toContain("reserve_wish");
  await page.getByLabel("Dein Name").fill("Oma Gisela");
  await page.getByRole("button", { name: "Jetzt reservieren" }).click();
  await expect(page.getByRole("heading", { name: "Reserviert!" })).toBeVisible();
  expect(calls.rpc).toContain("reserve_wish");

  expect(problems).toEqual([]);
});

test("Gästeansicht lässt sich zwischen Kacheln und Liste umschalten und merkt sich die Wahl", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await page.getByRole("button", { name: "Liste" }).click();
  await expect(page.locator(".ggrid.rows")).toBeVisible();
  await page.reload();
  await expect(page.locator(".ggrid.rows")).toBeVisible();
});

test("„Bitte besorgt ihr das Geschenk“ gibt es nur, wenn die Eltern es für die Liste erlauben", async ({ page }) => {
  await mockSupabase(page, { allowParentsBuy: false });
  await page.goto("/#/w/TOK");
  await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
  await expect(page.getByLabel("Dein Name")).toBeVisible();
  await expect(page.getByRole("checkbox", { name: /Bitte besorgt ihr das Geschenk/ })).toHaveCount(0);
});

test("Gäste können bitten, dass die Eltern das Geschenk besorgen", async ({ page }) => {
  const calls = await mockSupabase(page, { allowParentsBuy: true });
  await page.goto("/#/w/TOK");
  await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
  await page.getByLabel("Dein Name").fill("Oma Gisela");
  await page.getByRole("checkbox", { name: /Bitte besorgt ihr das Geschenk/ }).check();
  await page.getByRole("button", { name: "Jetzt reservieren" }).click();
  await expect(page.getByText("Die Eltern wissen Bescheid")).toBeVisible();
  expect(calls.bodies.find((b) => b.fn === "reserve_wish")).toMatchObject({ p_name: "Oma Gisela", p_parents_buy: true });
});

test("Gruppengeschenk: Gäste sehen nur die Summe und steuern einen Betrag bei", async ({ page }) => {
  const calls = await mockSupabase(page);
  await page.goto("/#/w/TOK");
  const card = page.locator(".gcard", { hasText: "Laufrad gemeinsam" });
  await expect(card.getByText("Gemeinsam", { exact: true })).toBeVisible();
  await expect(card).toContainText("100 € von 300 €");
  await expect(card).not.toContainText("Onkel Tobias");
  await expect(card.getByRole("button", { name: "Ich schenke es ganz" })).toHaveCount(0); // es gibt schon einen Beitrag
  await card.getByRole("button", { name: "Mitschenken" }).click();
  const dlg = page.locator("dialog.sheet[open]");
  await dlg.getByRole("button", { name: "50 €", exact: true }).click();
  await dlg.getByLabel("Dein Name").fill("Oma Gisela");
  await dlg.getByRole("button", { name: "50 € beisteuern" }).click();
  await expect(page.getByRole("heading", { name: "Danke!" })).toBeVisible();
  expect(calls.bodies.find((b) => b.fn === "contribute")).toMatchObject({ p_wish: "w4", p_amount_cents: 5000, p_name: "Oma Gisela" });
});

test("Gruppengeschenk: zu hohe Beträge lassen sich gar nicht erst abschicken", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await page.locator(".gcard", { hasText: "Laufrad gemeinsam" }).getByRole("button", { name: "Mitschenken" }).click();
  const dlg = page.locator("dialog.sheet[open]");
  await dlg.getByLabel("Anderer Betrag").fill("250");
  await dlg.getByLabel("Dein Name").fill("Test");
  await expect(dlg.getByText("Höchstens 200 €")).toBeVisible();
  await expect(dlg.getByRole("button", { name: /beisteuern/ })).toBeDisabled();
});

test("Kacheln: ein Tipp zeigt alle Details, auch die vollständige Notiz", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await page.getByRole("button", { name: "Kinderfahrrad 24 Zoll: alle Details" }).click();
  const sheet = page.locator("dialog.sheet[open]");
  await expect(sheet.getByRole("heading", { name: "Kinderfahrrad 24 Zoll" })).toBeVisible();
  await expect(sheet).toContainText("Mintgrün");
  await expect(sheet.getByRole("link", { name: "Bei Decathlon ansehen" })).toHaveAttribute("href", "https://www.decathlon.de/x");
  await sheet.getByRole("button", { name: "Reservieren" }).click();
  await expect(page.getByLabel("Dein Name")).toBeVisible();
});

test("Kacheln: in einer Reihe gleich hoch, Knöpfe auf einer Linie, Shop als Symbol", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  const tops = await page.locator(".ggrid.tiles .gcard .actions .btn.big").evaluateAll((els) => els.map((e) => Math.round(e.getBoundingClientRect().top)));
  expect(tops[0]).toBe(tops[1]); // erste Reihe: beide Knöpfe auf gleicher Höhe
  await expect(page.getByRole("link", { name: "„Kinderfahrrad 24 Zoll“ bei Decathlon ansehen" })).toBeVisible();
});

test("Erklärkasten: beim ersten Besuch offen, nach einer Reservierung eingeklappt", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await expect(page.locator(".howto-text")).toBeVisible();
  await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
  await page.getByLabel("Dein Name").fill("Oma Gisela");
  await page.getByRole("button", { name: "Jetzt reservieren" }).click();
  await expect(page.getByRole("heading", { name: "Reserviert!" })).toBeVisible();
  await page.reload();
  await expect(page.getByText("So funktioniert’s")).toBeVisible();
  await expect(page.locator(".howto-text")).toHaveCount(0);
});

test("Freudenmoment: nach dem Reservieren kurzer Konfetti-Regen, sichtbar über dem Dialog", async ({ page }) => {
  await mockSupabase(page);
  // Reihenfolge festhalten, in der Dialog und Konfetti erscheinen (was zuletzt kommt, liegt obenauf)
  await page.addInitScript(() => {
    const order: string[] = ((window as unknown as { __order: string[] }).__order = []);
    new MutationObserver((muts) => {
      for (const m of muts) {
        if (m.type === "attributes" && (m.target as Element).tagName === "DIALOG" && (m.target as HTMLDialogElement).open) order.push("dialog:" + ((m.target as Element).querySelector("h2")?.textContent ?? ""));
        if (m.type === "childList") m.addedNodes.forEach((n) => { if ((n as Element).classList?.contains("confetti")) order.push("konfetti"); });
      }
    }).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ["open"] });
  });
  await page.goto("/#/w/TOK");
  await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
  await page.getByLabel("Dein Name").fill("Oma Gisela");
  await page.getByRole("button", { name: "Jetzt reservieren" }).click();
  await expect(page.locator("canvas.confetti")).toHaveCount(1);
  // liegt in der obersten Ebene (wie die Dialoge) …
  expect(await page.locator("canvas.confetti").evaluate((c) => c.matches(":popover-open"))).toBe(true);
  // … und kommt erst nach dem „Reserviert!“-Dialog dorthin, liegt also obenauf
  const order = await page.evaluate(() => (window as unknown as { __order: string[] }).__order);
  expect(order.indexOf("konfetti")).toBeGreaterThan(order.lastIndexOf("dialog:Reserviert!"));
  await expect(page.locator("canvas.confetti")).toHaveCount(0, { timeout: 5000 }); // räumt sich selbst weg
});

test.describe("Bewegung reduziert", () => {
  test.use({ reducedMotion: "reduce" });
  test("kein Konfetti, wenn am Gerät „Bewegung reduzieren“ eingestellt ist", async ({ page }) => {
    await mockSupabase(page);
    await page.goto("/#/w/TOK");
    await page.locator(".gcard", { hasText: "Kinderfahrrad" }).getByRole("button", { name: "Reservieren" }).click();
    await page.getByLabel("Dein Name").fill("Oma Gisela");
    await page.getByRole("button", { name: "Jetzt reservieren" }).click();
    await expect(page.getByRole("heading", { name: "Reserviert!" })).toBeVisible();
    await expect(page.locator("canvas.confetti")).toHaveCount(0);
  });
});

test("Gruppengeschenk komplett: „Geschafft!“ und mehr Konfetti", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await page.locator(".gcard", { hasText: "Laufrad gemeinsam" }).getByRole("button", { name: "Mitschenken" }).click();
  const dlg = page.locator("dialog.sheet[open]");
  await dlg.getByRole("button", { name: /Rest/ }).click();
  await dlg.getByLabel("Dein Name").fill("Oma Gisela");
  await dlg.getByRole("button", { name: /beisteuern/ }).click();
  await expect(page.getByRole("heading", { name: "Geschafft! Das Geschenk ist komplett." })).toBeVisible();
  await expect(page.locator("canvas.confetti")).toHaveCount(1);
});

test("Kacheln: „Mitschenken“ steht auf derselben Höhe wie „Reservieren“", async ({ page }) => {
  await mockSupabase(page);
  await page.route(/rpc\/guest_list/, (r) => r.fulfill({ json: {
    id: "x", title: "Emmas 9. Geburtstag", recipient_name: "Emma", occasion: "birthday", event_date: "2026-12-14", description: null, cover: 0,
    wishes: [
      { id: "a", title: "Laufrad gemeinsam", url: null, shop: null, image_path: null, price_cents: 30000, quantity: 1, priority: "heart", note: null, group_gift: true, target_cents: 30000, funded_cents: 0, contributors: 0, available: 1 },
      { id: "b", title: "Kinderfahrrad 24 Zoll", url: null, shop: null, image_path: null, price_cents: 34900, quantity: 1, priority: "heart", note: "Mintgrün", available: 1 },
    ] } }));
  await page.goto("/#/w/TOK");
  const tops = await page.locator(".ggrid.tiles .gcard .actions .btn.big").evaluateAll((els) => els.map((e) => Math.round(e.getBoundingClientRect().top)));
  expect(tops[0]).toBe(tops[1]);
  await expect(page.locator(".ggrid.tiles").getByRole("button", { name: "Ich schenke es ganz" })).toHaveCount(0);
  // In der Detailansicht gibt es „Ich schenke es ganz“ weiterhin
  await page.getByRole("button", { name: "Laufrad gemeinsam: alle Details" }).click();
  await expect(page.locator("dialog.sheet[open]").getByRole("button", { name: "Ich schenke es ganz" })).toBeVisible();
});

test("Schenkende: „Deine Wunschlisten“ zeigt die auf dem Gerät geöffneten Listen", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  await expect(page.getByRole("heading", { name: "Emmas 9. Geburtstag" })).toBeVisible();
  await expect(page).toHaveURL(/[?&]liste=TOK/); // Merkhilfe für den Start als App
  // Päckli ohne Link öffnen: statt der Anmeldung erscheinen die Wunschlisten
  await page.goto("/#/");
  await expect(page.getByRole("heading", { name: "Deine Wunschlisten" })).toBeVisible();
  await expect(page).not.toHaveURL(/liste=/); // Merkhilfe beim Verlassen entfernt
  await page.getByRole("link", { name: /Emmas 9. Geburtstag/ }).click();
  await expect(page).toHaveURL(/#\/w\/TOK/);
  // Eltern können sich weiterhin anmelden
  await page.goto("/#/");
  await page.getByRole("region", { name: "Mit Konto schenken" }).getByRole("link", { name: "Anmelden oder Konto anlegen" }).click();
  await expect(page.getByRole("button", { name: /Anmelde-Mail/ })).toBeVisible();
  // Liste aus der Übersicht entfernen
  await page.goto("/#/");
  await page.getByRole("button", { name: "„Emmas 9. Geburtstag“ aus dieser Übersicht entfernen" }).click();
  await expect(page.getByText("Noch keine Wunschliste")).toBeVisible();
});

test("Schenkende: Hinweis „Päckli als App speichern“ mit Anleitung, ausblendbar", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  const hint = page.getByRole("region", { name: "Päckli als App" });
  await expect(hint).toBeVisible();
  await hint.getByRole("button", { name: "So geht’s" }).click();
  await expect(page.locator("dialog.sheet[open]")).toContainText("Startbildschirm");
  await page.getByRole("button", { name: "Verstanden" }).click();
  await hint.getByRole("button", { name: "Hinweis ausblenden" }).click();
  await page.reload();
  await expect(page.getByRole("heading", { name: "Emmas 9. Geburtstag" })).toBeVisible();
  await expect(page.getByRole("region", { name: "Päckli als App" })).toHaveCount(0);
});

test("Gästeansicht: Hinweis aufs Konto, nach der Anmeldung zurück zur Wunschliste", async ({ page }) => {
  await mockSupabase(page);
  await page.goto("/#/w/TOK");
  const hint = page.getByRole("region", { name: "Mit Konto schenken" });
  await expect(hint).toContainText("Du schenkst öfter?");
  await hint.getByRole("link", { name: "Anmelden oder Konto anlegen" }).click();
  await expect(page.getByText("Zum Reservieren brauchst du kein Konto.")).toBeVisible();
  await expect(page.getByText("Neue Konten gibt die Familie frei.")).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem("paeckli-nach-anmeldung"))).toBe("/w/TOK");
  // Anmeldung abgeschlossen (z. B. per Link aus der Mail): zurück zur Wunschliste, nicht zur Übersicht
  await mockSupabase(page, { signedIn: true, guestAccount: true });
  await page.goto("/#/");
  await page.reload(); // wie beim Öffnen des Links aus der Mail: Seite startet neu, jetzt angemeldet
  await expect(page).toHaveURL(/#\/w\/TOK/);
  expect(await page.evaluate(() => localStorage.getItem("paeckli-nach-anmeldung"))).toBeNull();
});

test("Angemeldet: kein Hinweis aufs Konto in der Gästeansicht", async ({ page }) => {
  await mockSupabase(page, { signedIn: true, guestAccount: true });
  await page.goto("/#/w/TOK");
  await expect(page.getByRole("heading", { name: "Emmas 9. Geburtstag" })).toBeVisible();
  await expect(page.getByRole("region", { name: "Mit Konto schenken" })).toHaveCount(0);
});
