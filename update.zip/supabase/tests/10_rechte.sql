-- =====================================================================
-- Päckli – Datenbank-Tests: Jede Prüfung bricht bei einem Fehler mit klarer Meldung ab.
-- =====================================================================
\set ON_ERROR_STOP 1
create function pg_temp.pruefe(ok boolean, was text) returns void language plpgsql as
  $$ begin if not coalesce(ok, false) then raise exception 'FEHLGESCHLAGEN: %', was; end if; raise notice 'OK: %', was; end $$;
create function pg_temp.als(uid text) returns void language plpgsql as $$
begin
  if uid is null then execute 'reset role'; perform set_config('request.jwt.claim.sub', '', false);
  elsif uid = 'anon' then execute 'set role anon'; perform set_config('request.jwt.claim.sub', '', false);
  else execute 'set role authenticated'; perform set_config('request.jwt.claim.sub', uid, false); end if;
end $$;

insert into allowed_emails (email, account_type) values ('julia@test.de', 'family'), ('markus@test.de', 'family'), ('fremd@test.de', 'guest');
insert into auth.users values ('11111111-1111-1111-1111-111111111111', 'julia@test.de'),
  ('22222222-2222-2222-2222-222222222222', 'markus@test.de'), ('33333333-3333-3333-3333-333333333333', 'fremd@test.de');
do $$ begin insert into auth.users values ('44444444-4444-4444-4444-444444444444', 'nicht@freigeschaltet.de');
  raise exception 'FEHLGESCHLAGEN: nicht freigeschaltete Adresse konnte sich registrieren'; exception when insufficient_privilege then raise notice 'OK: Zugangsliste blockiert fremde Adressen'; end $$;

-- Julia legt eine Liste mit Wünschen an
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select id as liste from create_list('Emmas Geburtstag', 'Emma', 'birthday', (current_date + 30)) \gset
select id as liste2 from create_list('Leons Liste') \gset
select set_config('test.liste2', :'liste2', false) is not null as x \gset
insert into wishes (list_id, title, quantity, priority, created_by) values
  (:'liste', 'Fahrrad', 1, 'heart', auth.uid()), (:'liste', 'Hörspiele', 3, 'nice', auth.uid());
select create_invite(:'liste') as einladung \gset
select pg_temp.als(null);
select guest_token as gast from lists where id = :'liste' \gset
select id as rad from wishes where title = 'Fahrrad' \gset
select id as hoer from wishes where title = 'Hörspiele' \gset

-- Fremde sehen nichts
select pg_temp.als('33333333-3333-3333-3333-333333333333');
select pg_temp.pruefe((select count(*) from lists) = 0 and (select count(*) from wishes) = 0, 'Fremdes Konto sieht keine Listen und Wünsche');
select pg_temp.als('anon');
select pg_temp.pruefe((select count(*) from wishes) = 0, 'Gäste haben keinen direkten Tabellenzugriff');

-- Einladung: einmalig
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe(accept_invite(:'einladung') = :'liste'::uuid, 'Markus nimmt die Einladung an');
select set_config('test.einladung', :'einladung', false) is not null as x \gset
select pg_temp.als('33333333-3333-3333-3333-333333333333');
do $$ begin perform accept_invite(current_setting('test.einladung')); raise exception 'FEHLGESCHLAGEN: Einladung ein zweites Mal angenommen';
  exception when sqlstate '22023' then raise notice 'OK: Einladung funktioniert kein zweites Mal'; end $$;
select pg_temp.pruefe((select count(*) from lists) = 0, 'Zweiter Empfänger sieht die Liste nicht');

-- Mitbearbeiter darf bearbeiten, aber nicht löschen oder einladen
select pg_temp.als('22222222-2222-2222-2222-222222222222');
update wishes set price_cents = 34900 where id = :'rad';
select pg_temp.pruefe((select price_cents from wishes where id = :'rad') = 34900, 'Mitbearbeiter kann Wünsche bearbeiten');
delete from lists where id = :'liste';
select pg_temp.pruefe((select count(*) from lists where id = :'liste') = 1, 'Mitbearbeiter kann die Liste nicht löschen');
do $$ begin perform create_invite((select id from lists limit 1)); raise exception 'FEHLGESCHLAGEN: Mitbearbeiter konnte einladen';
  exception when insufficient_privilege then raise notice 'OK: Mitbearbeiter kann nicht einladen'; end $$;

-- Gäste: reservieren mit Pflichtnamen, keine Namen sichtbar, keine Überbuchung
select pg_temp.als('anon');
select pg_temp.pruefe(reserve_wish(:'gast', :'rad', 1, '  ')->>'error' = 'name_required', 'Reservieren ohne Namen wird abgelehnt');
select reserve_wish(:'gast', :'rad', 1, 'Oma Gisela')->>'code' as code \gset
select pg_temp.pruefe(:'code' ~ '^[A-Z2-9]{4}-[A-Z2-9]{4}$', 'Gast bekommt einen Code');
select pg_temp.pruefe(reserve_wish(:'gast', :'rad', 1, 'Onkel')->>'error' = 'already_taken', 'Vergebener Wunsch kann nicht doppelt reserviert werden');
select pg_temp.pruefe(reserve_wish(:'gast', :'hoer', 4, 'Viel')->>'error' = 'already_taken', 'Mengen-Wunsch kann nicht überbucht werden');
select pg_temp.pruefe(guest_list(:'gast')::text not like '%Oma%', 'Gästeansicht verrät keine Namen');
select pg_temp.pruefe((cancel_reservation('ZZZZ-ZZZZ')->>'ok')::boolean = false, 'Falscher Code hebt nichts auf');
select pg_temp.pruefe((cancel_reservation(lower(:'code'))->>'ok')::boolean, 'Richtiger Code hebt die Reservierung auf');

-- Eltern sehen Namen, Schalter blendet aus, Menge nicht unter Reservierungen
select reserve_wish(:'gast', :'hoer', 2, 'Familie Yilmaz') is not null as x \gset
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe((select string_agg(guest_name, ',') from reservations) = 'Familie Yilmaz', 'Eltern sehen, wer reserviert hat');
select set_show_reservations(:'liste', false);
select pg_temp.pruefe((select count(*) from reservations) = 0, 'Schalter blendet Reservierungen aus');
select set_show_reservations(:'liste', true);
do $$ begin update wishes set quantity = 1 where title = 'Hörspiele'; raise exception 'FEHLGESCHLAGEN: Menge unter Reservierung gesenkt';
  exception when check_violation then raise notice 'OK: Menge kann nicht unter die Reservierungen sinken'; end $$;
select pg_temp.als('11111111-1111-1111-1111-111111111111');
do $$ begin update wishes set list_id = current_setting('test.liste2')::uuid where title = 'Hörspiele'; raise exception 'FEHLGESCHLAGEN: reservierter Wunsch verschoben';
  exception when check_violation then raise notice 'OK: Reservierte Wünsche bleiben in ihrer Liste'; end $$;
update wishes set list_id = :'liste2' where title = 'Fahrrad';
select pg_temp.pruefe((select list_id from wishes where title = 'Fahrrad') = :'liste2'::uuid, 'Freie Wünsche lassen sich verschieben');
update wishes set list_id = :'liste' where title = 'Fahrrad';

-- Abgeschlossene Listen sind für Gäste pausiert; Erinnerungen nur für den Server
select pg_temp.als('11111111-1111-1111-1111-111111111111');
do $$ begin perform reminder_batch(current_date); raise exception 'FEHLGESCHLAGEN: App kann Erinnerungsdaten lesen';
  exception when insufficient_privilege then raise notice 'OK: App hat keinen Zugriff auf Erinnerungsdaten'; end $$;
update lists set archived_at = now() where id = :'liste';
select pg_temp.als('anon');
select pg_temp.pruefe(guest_list(:'gast') is null, 'Abgeschlossene Liste ist für Gäste nicht erreichbar');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
update lists set archived_at = null where id = :'liste';

-- Bremsklotz: höchstens 10 Reservierungen pro Liste und Minute
insert into wishes (list_id, title, quantity, created_by) values (:'liste', 'Sticker', 20, auth.uid());
select pg_temp.als(null);
select id as sticker from wishes where title = 'Sticker' \gset
delete from rate_events;
select pg_temp.als('anon');
create temp table bremse as select g, reserve_wish(:'gast', :'sticker', 1, 'Gast ' || g)->>'error' as fehler from generate_series(1, 12) g;
select pg_temp.pruefe((select count(*) from bremse where fehler is null) = 10 and (select count(*) from bremse where fehler = 'rate_limited') = 2,
  'Bremsklotz lässt 10 Reservierungen pro Minute zu und stoppt weitere');

-- Fehlerprotokoll: nur schreiben, nie lesen
select log_client_error('Testfehler');
select pg_temp.pruefe((select count(*) from client_errors) = 0, 'Fehlerprotokoll ist aus der App nicht lesbar');
select pg_temp.als(null);
select pg_temp.pruefe((select count(*) from client_errors) = 1, 'Fehler wurde protokolliert');


-- Eltern besorgen, Eltern reservieren, Benachrichtigungen
select pg_temp.als('11111111-1111-1111-1111-111111111111');
insert into wishes (list_id, title, quantity, created_by) values (:'liste', 'Zelt', 1, auth.uid()), (:'liste', 'Puppe', 1, auth.uid());
select pg_temp.als(null);
select id as zelt from wishes where title = 'Zelt' \gset
select id as puppe from wishes where title = 'Puppe' \gset
delete from rate_events;
select clock_timestamp() as vorher \gset
select pg_temp.als('anon');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
update lists set allow_parents_buy = true where id = :'liste';
select pg_temp.als('anon');
select pg_temp.pruefe((reserve_wish(:'gast', :'zelt', 1, 'Oma Gisela', true)->>'ok')::boolean, 'Gast reserviert mit „Bitte besorgt ihr es“');
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe((select parents_buy from reservations r join wishes w on w.id = r.wish_id where w.title = 'Zelt'), 'Eltern sehen „Eltern besorgen“');
select pg_temp.pruefe((reserve_for_guest(:'puppe', 1, 'Opa Heinz', true)->>'ok')::boolean, 'Eltern reservieren für jemanden');
select pg_temp.pruefe((select entered_by from reservations r join wishes w on w.id = r.wish_id where w.title = 'Puppe') = auth.uid(), 'Eintrag merkt sich, wer ihn gemacht hat');
select pg_temp.pruefe(reserve_for_guest(:'puppe', 1, 'Tante')->>'error' = 'already_taken', 'Auch Eltern können nicht doppelt reservieren');
select pg_temp.als('33333333-3333-3333-3333-333333333333');
do $$ begin perform reserve_for_guest((select id from wishes limit 1), 1, 'X'); raise exception 'FEHLGESCHLAGEN: Fremde konnten reservieren';
  exception when insufficient_privilege then raise notice 'OK: Fremde können nicht für andere reservieren'; end $$;
select pg_temp.als('anon');
select pg_temp.pruefe(guest_list(:'gast')::text not like '%Opa Heinz%' and (guest_list(:'gast')->'wishes')::text not like '%parents_buy%', 'Gäste erfahren weder Namen noch „Eltern besorgen“');

-- Benachrichtigungen: nur für den Server, ohne eigene Einträge
select pg_temp.als('11111111-1111-1111-1111-111111111111');
do $$ begin perform reservation_notices('daily', now() - interval '1 day', now()); raise exception 'FEHLGESCHLAGEN: App kann Benachrichtigungen lesen';
  exception when insufficient_privilege then raise notice 'OK: App hat keinen Zugriff auf Benachrichtigungen'; end $$;
select pg_temp.als(null);
create temp table hinweise as select * from reservation_notices('daily', :'vorher', now());
select pg_temp.pruefe((select count(*) from hinweise where email = 'julia@test.de') = 1
  and (select jsonb_array_length(items) from hinweise where email = 'julia@test.de') = 2, 'Julia erfährt von beiden neuen Reservierungen');
select pg_temp.pruefe((select count(*) from hinweise h, jsonb_array_elements(h.items) i where h.email = 'markus@test.de' and i->>'name' = 'Opa Heinz') = 0
  and (select count(*) from hinweise where email = 'markus@test.de') = 1, 'Markus wird über seinen eigenen Eintrag nicht benachrichtigt');
update profiles set notify_reservations = 'off' where id = '11111111-1111-1111-1111-111111111111';
select pg_temp.pruefe((select count(*) from reservation_notices('daily', :'vorher', now()) where email = 'julia@test.de') = 0, 'Wer „aus“ wählt, bekommt nichts');
update profiles set notify_reservations = 'daily' where id = '11111111-1111-1111-1111-111111111111';
update list_members set show_reservations = false where user_id = '11111111-1111-1111-1111-111111111111';
select pg_temp.pruefe((select count(*) from reservation_notices('daily', :'vorher', now()) where email = 'julia@test.de') = 0, 'Ausgeblendete Reservierungen werden nicht verraten');
update list_members set show_reservations = true;

do $$ begin update profiles set notify_reservations = 'instant' where id = '11111111-1111-1111-1111-111111111111';
  raise exception 'FEHLGESCHLAGEN: „Sofort“ ließ sich noch einstellen'; exception when check_violation then raise notice 'OK: Benachrichtigungen nur noch täglich oder aus'; end $$;


-- Gruppengeschenke
select pg_temp.als('11111111-1111-1111-1111-111111111111');
do $$ begin insert into wishes (list_id, title, group_gift, created_by) values ((select id from lists where title = 'Emmas Geburtstag'), 'Ohne Preis', true, auth.uid());
  raise exception 'FEHLGESCHLAGEN: Gruppengeschenk ohne Preis angelegt'; exception when check_violation then raise notice 'OK: Gruppengeschenk braucht einen Preis'; end $$;
insert into wishes (list_id, title, price_cents, group_gift, created_by) values (:'liste', 'Kinderfahrrad gemeinsam', 34900, true, auth.uid());
select pg_temp.als(null);
select id as gruppe from wishes where title = 'Kinderfahrrad gemeinsam' \gset
delete from rate_events;
select pg_temp.als('anon');
select pg_temp.pruefe(reserve_wish(:'gast', :'gruppe', 1, 'Oma')->>'error' = 'group_gift', 'Gruppengeschenk lässt sich nicht normal reservieren');
select pg_temp.pruefe(contribute(:'gast', :'gruppe', 300, 'Klein')->>'error' = 'too_little', 'Beitrag unter 5 € wird abgelehnt');
select pg_temp.pruefe(contribute(:'gast', :'gruppe', 40000, 'Viel')->>'error' = 'too_much', 'Mehr als der offene Rest wird abgelehnt');
select contribute(:'gast', :'gruppe', 10000, 'Oma Gisela')->>'code' as beitrag \gset
select pg_temp.pruefe(:'beitrag' ~ '^[A-Z2-9]{4}-[A-Z2-9]{4}$', 'Gast steuert 100 € bei und bekommt einen Code');
select pg_temp.pruefe((select (w->>'funded_cents')::int = 10000 and (w->>'contributors')::int = 1 and (w->>'available')::int = 1
  from jsonb_array_elements(guest_list(:'gast')->'wishes') w where w->>'id' = :'gruppe'), 'Gäste sehen Summe und Anzahl');
select pg_temp.pruefe(guest_list(:'gast')::text not like '%Oma Gisela%', 'Gäste sehen keine Namen der Beitragenden');
select pg_temp.pruefe((select sum(quantity) from my_reservations(array[:'beitrag'])) = 0
  and (select sum(amount_cents) from my_reservations(array[:'beitrag'])) = 10000, 'Eigener Beitrag ist mit Betrag abrufbar');

select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe((contribute_for_guest(:'gruppe', 5000, 'Onkel Tobias')->>'ok')::boolean, 'Eltern tragen einen Beitrag für jemanden ein');
do $$ begin update wishes set group_gift = false where title = 'Kinderfahrrad gemeinsam'; raise exception 'FEHLGESCHLAGEN: Umschalten trotz Beiträgen';
  exception when check_violation then raise notice 'OK: Gemeinsam-Schenken lässt sich mit Beiträgen nicht abschalten'; end $$;
select pg_temp.pruefe((select string_agg(guest_name || ':' || amount_cents, ',' order by amount_cents) from reservations where wish_id = :'gruppe') = 'Onkel Tobias:5000,Oma Gisela:10000', 'Eltern sehen Namen und Beträge');

select pg_temp.als(null);
select pg_temp.pruefe((select gift_target(w) - gift_funded(w.id) from wishes w where id = :'gruppe') = 19900, 'Offener Rest wird richtig berechnet (349 − 100 − 50 = 199 €)');
select pg_temp.als('anon');
select pg_temp.pruefe((contribute(:'gast', :'gruppe', 19900, 'Tante Sabine')->>'ok')::boolean, 'Den Rest übernehmen geht');
select pg_temp.pruefe(contribute(:'gast', :'gruppe', 500, 'Noch wer')->>'error' = 'fully_funded', 'Komplett finanziert: keine weiteren Beiträge');
select pg_temp.pruefe((select (w->>'available')::int = 0 from jsonb_array_elements(guest_list(:'gast')->'wishes') w where w->>'id' = :'gruppe'), 'Komplett finanziert gilt als vergeben');
select pg_temp.pruefe((cancel_reservation(:'beitrag')->>'ok')::boolean, 'Gast zieht seinen Beitrag zurück');
select pg_temp.pruefe((select (w->>'funded_cents')::int = 24900 and (w->>'available')::int = 1 from jsonb_array_elements(guest_list(:'gast')->'wishes') w where w->>'id' = :'gruppe'), 'Danach ist wieder etwas offen');
select pg_temp.als(null);
select pg_temp.pruefe((select count(*) from reservation_notices('daily', now() - interval '1 hour', now()) n, jsonb_array_elements(n.items) i where i->>'amount_cents' = '5000') >= 1, 'Tägliche Mail enthält die Beträge');


-- „Bitte besorgt ihr es“ nur mit Erlaubnis der Eltern
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select id as liste3, guest_token as gast3 from create_list('Ohne Besorgen') \gset
select pg_temp.pruefe(not (select allow_parents_buy from lists where id = :'liste3'), 'Neue Listen erlauben „Bitte besorgt ihr es“ zunächst nicht');
insert into wishes (list_id, title, created_by) values (:'liste3', 'Ball', auth.uid()), (:'liste3', 'Kreisel', auth.uid());
select pg_temp.als(null);
select id as ball from wishes where title = 'Ball' and list_id = :'liste3' \gset
select id as kreisel from wishes where title = 'Kreisel' and list_id = :'liste3' \gset
delete from rate_events;
select pg_temp.als('anon');
select pg_temp.pruefe((guest_list(:'gast3')->>'allow_parents_buy')::boolean = false, 'Gästeansicht weiß, dass die Option nicht angeboten wird');
select reserve_wish(:'gast3', :'ball', 1, 'Oma', true) is not null as x \gset
select pg_temp.als(null);
select pg_temp.pruefe(not (select parents_buy from reservations where wish_id = :'ball'), 'Ohne Erlaubnis wird „Bitte besorgt ihr es“ ignoriert');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
update lists set allow_parents_buy = true where id = :'liste3';
select pg_temp.als('anon');
select reserve_wish(:'gast3', :'kreisel', 1, 'Opa', true) is not null as x \gset
select pg_temp.als(null);
select pg_temp.pruefe((select parents_buy from reservations where wish_id = :'kreisel'), 'Mit Erlaubnis wird „Bitte besorgt ihr es“ gespeichert');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe((select allow_parents_buy from create_list('Mit Besorgen', null, 'birthday', null, 0, null, true)), 'Beim Anlegen lässt sich die Option gleich einschalten');


-- Listen-Reihenfolge: jeder nur seine eigene
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select set_list_order(array[:'liste2', :'liste']::uuid[]);
select pg_temp.pruefe((select sort_order from list_members where list_id = :'liste2' and user_id = auth.uid()) = 1
  and (select sort_order from list_members where list_id = :'liste' and user_id = auth.uid()) = 2, 'Eigene Reihenfolge wird gespeichert');
select pg_temp.pruefe((select sort_order from list_members where list_id = :'liste' and user_id = '22222222-2222-2222-2222-222222222222') is null, 'Die Reihenfolge anderer Mitglieder bleibt unberührt');
update profiles set list_sort = 'name' where id = auth.uid();
select pg_temp.pruefe((select list_sort from profiles where id = auth.uid()) = 'name', 'Sortierung lässt sich pro Person merken');
select pg_temp.als('33333333-3333-3333-3333-333333333333');
select set_list_order(array[:'liste']::uuid[]);
select pg_temp.als(null);
select pg_temp.pruefe(not exists (select 1 from list_members where list_id = :'liste' and user_id = '33333333-3333-3333-3333-333333333333'), 'Fremde können über die Reihenfolge keinen Zugang erlangen');


-- Zuletzt gesucht: nur für einen selbst
select pg_temp.als('11111111-1111-1111-1111-111111111111');
insert into recent_searches (terms) values (array['Lego Baumhaus', 'Hörspiel']);
select pg_temp.pruefe((select terms from recent_searches) = array['Lego Baumhaus', 'Hörspiel'], 'Eigene Suchbegriffe werden gespeichert');
do $$ begin update recent_searches set terms = array['a', 'b', 'c', 'd'] where user_id = auth.uid(); raise exception 'FEHLGESCHLAGEN: mehr als 3 Begriffe';
  exception when check_violation then raise notice 'OK: Höchstens 3 Begriffe'; end $$;
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe((select count(*) from recent_searches) = 0, 'Mitbearbeiter sehen die Suchen anderer nicht');
update recent_searches set terms = array['Hack'] where user_id = '11111111-1111-1111-1111-111111111111';
do $$ begin insert into recent_searches (user_id, terms) values ('11111111-1111-1111-1111-111111111111', array['Hack']); raise exception 'FEHLGESCHLAGEN: fremde Suchen angelegt';
  exception when insufficient_privilege or unique_violation then raise notice 'OK: Fremde Suchen lassen sich nicht anlegen'; end $$;
select pg_temp.als(null);
select pg_temp.pruefe((select terms from recent_searches where user_id = '11111111-1111-1111-1111-111111111111') = array['Lego Baumhaus', 'Hörspiel'], 'Fremde können die Suchen nicht ändern');
select pg_temp.als('anon');
select pg_temp.pruefe((select count(*) from recent_searches) = 0, 'Gäste sehen keine Suchbegriffe');
select pg_temp.als(null);


-- Freigabe neuer Bearbeiter
select pg_temp.als(null);
insert into app_admins (user_id) values ('11111111-1111-1111-1111-111111111111');
select pg_temp.als('anon');
do $$ begin perform request_access('neu@test.de', '1.1.1.1'); raise exception 'FEHLGESCHLAGEN: Gäste rufen request_access direkt auf';
  exception when insufficient_privilege then raise notice 'OK: Anfragen laufen nur über den Server'; end $$;
select pg_temp.als(null);
set role service_role;
delete from rate_events where bucket like 'access:%';
select pg_temp.pruefe(request_access('Neu@Test.de', '1.1.1.1') = '{"status": "pending", "notify": true}'::jsonb, 'Unbekannte Adresse erzeugt eine Anfrage und benachrichtigt die Verwaltung');
select pg_temp.pruefe(request_access('neu@test.de', '1.1.1.1') = '{"status": "pending", "notify": false}'::jsonb, 'Wiederholte Anfrage benachrichtigt nicht erneut');
select pg_temp.pruefe(request_access('julia@test.de', '1.1.1.1')->>'status' = 'allowed', 'Bekannte Adresse bekommt sofort ihren Code');
reset role;

select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe(is_admin(), 'Julia ist Administratorin');
select pg_temp.pruefe(allow_email('direkt@test.de') = 'allowed', 'Administratorin lädt ein: sofort freigeschaltet');
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe(not is_admin(), 'Markus ist kein Administrator');
select id as markusliste from create_list('Markus’ Liste') \gset
select pg_temp.pruefe(allow_email('anna@test.de', :'markusliste') = 'pending', 'Markus lädt ein: es entsteht eine Anfrage');
do $$ begin perform pending_access_requests(); raise exception 'FEHLGESCHLAGEN: Nicht-Admin sieht Anfragen';
  exception when insufficient_privilege then raise notice 'OK: Nur Administratoren sehen Anfragen'; end $$;
do $$ begin insert into auth.users values ('55555555-5555-5555-5555-555555555555', 'anna@test.de'); raise exception 'FEHLGESCHLAGEN: Anna kam ohne Freigabe rein';
  exception when insufficient_privilege then raise notice 'OK: Ohne Freigabe kein Konto'; end $$;

select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe((select count(*) from pending_access_requests()) = 2, 'Administratorin sieht beide offenen Anfragen');
select pg_temp.pruefe((select invited_by_name || ' / ' || list_title from pending_access_requests() where email = 'anna@test.de') like '% / Markus’ Liste', 'Anfrage zeigt, wer wozu eingeladen hat');
select id as anna_req from pending_access_requests() where email = 'anna@test.de' \gset
select id as neu_req from pending_access_requests() where email = 'neu@test.de' \gset
select pg_temp.pruefe(decide_access(:'anna_req', true) = 'anna@test.de', 'Freigeben liefert die Adresse für die Code-Mail');
select pg_temp.pruefe(decide_access(:'neu_req', false) = 'neu@test.de', 'Ablehnen geht auch');
select pg_temp.pruefe((select count(*) from pending_access_requests()) = 0, 'Danach ist nichts mehr offen');
select pg_temp.als(null);
insert into auth.users values ('55555555-5555-5555-5555-555555555555', 'anna@test.de');
select pg_temp.pruefe(exists (select 1 from profiles where id = '55555555-5555-5555-5555-555555555555'), 'Nach der Freigabe kann Anna ihr Konto anlegen');
set role service_role;
select pg_temp.pruefe(request_access('neu@test.de', '1.1.1.1') = '{"status": "pending", "notify": false}'::jsonb, 'Abgelehnte Adresse erfährt nichts und löst keine neue Mail aus');
select pg_temp.pruefe((select count(*) from admin_emails()) = 1, 'Der Server findet die Adresse der Verwaltung');
reset role;


-- Zweite Sicherungsschicht: nur für Angemeldete gedachte Funktionen sind für Gäste gar nicht aufrufbar
select pg_temp.pruefe(not has_function_privilege('anon', 'public.' || f, 'execute'), 'Gäste können ' || split_part(f, '(', 1) || ' nicht aufrufen')
from unnest(array['allow_email(text, uuid)', 'reserve_for_guest(uuid, integer, text, boolean)', 'contribute_for_guest(uuid, integer, text)',
                  'pending_access_requests()', 'decide_access(uuid, boolean, text)', 'is_admin()']) f;
select pg_temp.pruefe(has_function_privilege('anon', 'public.' || f, 'execute'), 'Gäste dürfen ' || split_part(f, '(', 1) || ' weiterhin nutzen')
from unnest(array['guest_list(text)', 'reserve_wish(text, uuid, integer, text, boolean)', 'contribute(text, uuid, integer, text)',
                  'cancel_reservation(text)', 'my_reservations(text[])', 'log_client_error(text, text, text, text)']) f;


-- Verlauf
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select id as vliste, guest_token as vgast from create_list('Verlaufstest', 'Emma') \gset
insert into wishes (list_id, title, price_cents, quantity, created_by) values (:'vliste', 'Laufrad', 34900, 2, auth.uid());
select pg_temp.als(null);
select id as laufrad from wishes where title = 'Laufrad' and list_id = :'vliste' \gset
insert into list_members (list_id, user_id, role) values (:'vliste', '22222222-2222-2222-2222-222222222222', 'editor');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
update wishes set price_cents = 32900 where id = :'laufrad';
select pg_temp.pruefe((select data->'changes'->'price_cents' = '{"alt": 34900, "neu": 32900}'::jsonb and lower(actor_name) = 'julia'
  from audit_log where entity_id = :'laufrad' and action = 'updated' order by id desc limit 1), 'Preisänderung mit altem und neuem Wert und Namen');
select rotate_guest_link(:'vliste') is not null as x \gset
select guest_token as vgast from lists where id = :'vliste' \gset
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste' and action = 'link_renewed' and data::text not like '%' || :'vgast' || '%') = 1, 'Gast-Link-Erneuerung protokolliert, ohne den Link selbst');

-- Reservierungen: Gast reserviert und hebt auf, Eltern geben frei
select pg_temp.als(null);
delete from rate_events;
select pg_temp.als('anon');
select reserve_wish(:'vgast', :'laufrad', 1, 'Oma Gisela')->>'code' as vcode \gset
select reserve_wish(:'vgast', :'laufrad', 1, 'Opa Heinz') is not null as x \gset
select pg_temp.pruefe((cancel_reservation(:'vcode')->>'ok')::boolean, 'Gast hebt eigene Reservierung auf');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
delete from reservations where guest_name = 'Opa Heinz' and wish_id = :'laufrad';
select pg_temp.pruefe((select string_agg(action || ':' || actor_name, ',' order by id) from audit_log where list_id = :'vliste' and kind = 'reservation')
  = 'reserved:Oma Gisela,reserved:Opa Heinz,cancelled:Oma Gisela,released:julia', 'Reservieren, Aufheben durch Gast und Freigeben durch Eltern mit richtigen Namen');
select pg_temp.pruefe((select bool_and(forget_after is not null) from audit_log where list_id = :'vliste' and kind = 'reservation'), 'Reservierungs-Einträge verfallen mit der Reservierung');

-- Überraschungsschutz und Sichtbarkeit
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste' and kind = 'reservation') = 4, 'Mitbearbeiter sieht Reservierungen im Verlauf');
select set_show_reservations(:'vliste', false);
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste' and kind = 'reservation') = 0
  and (select count(*) from audit_log where list_id = :'vliste' and kind = 'wish') > 0, 'Ausgeblendete Reservierungen bleiben auch im Verlauf verborgen');
select set_show_reservations(:'vliste', true);
select pg_temp.pruefe((select count(*) from audit_log where kind = 'access') = 0, 'Zugangsprotokoll nur für Administratoren');
select pg_temp.als('33333333-3333-3333-3333-333333333333');
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste') = 0, 'Fremde sehen keinen Verlauf');
select pg_temp.als(null);
select pg_temp.pruefe(not has_table_privilege('anon', 'public.audit_log', 'select'), 'Gäste haben keinen Zugriff auf den Verlauf');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe((select count(*) from audit_log where kind = 'access') > 0, 'Administratorin sieht das Zugangsprotokoll');

-- Fälschungssicher
do $$ begin insert into audit_log (list_id, kind, action) values ((select id from lists where title = 'Verlaufstest'), 'wish', 'gefälscht');
  raise exception 'FEHLGESCHLAGEN: Eintrag gefälscht'; exception when insufficient_privilege then raise notice 'OK: Einträge lassen sich nicht fälschen'; end $$;
select count(*) as vorher_alle from audit_log \gset
do $$ begin delete from audit_log; exception when insufficient_privilege then null; end $$;
do $$ begin update audit_log set actor_name = 'Jemand'; exception when insufficient_privilege then null; end $$;
select pg_temp.als(null);
select pg_temp.pruefe((select count(*) from audit_log where actor_name = 'Jemand') = 0, 'Verlauf lässt sich nicht ändern');
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe((select count(*) from audit_log) = :'vorher_alle'::int, 'Verlauf lässt sich nicht löschen');

-- Wunsch mit Reservierung löschen: ein Eintrag, keine Flut von Freigaben
select pg_temp.als(null);
delete from rate_events;
select pg_temp.als('anon');
select reserve_wish(:'vgast', :'laufrad', 2, 'Tante Sabine') is not null as x \gset
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select count(*) as vorher from audit_log where list_id = :'vliste' and kind = 'reservation' \gset
delete from wishes where id = :'laufrad';
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste' and kind = 'reservation') = :'vorher'::int
  and (select count(*) from audit_log where entity_id = :'laufrad' and action = 'deleted') = 1, 'Wunsch löschen: ein Eintrag, keine einzelnen Freigaben');

-- Aufräumen: abgelaufene Gästenamen und Einträge älter als ein Jahr verschwinden
select pg_temp.als(null);
update audit_log set forget_after = current_date - 1 where list_id = :'vliste' and kind = 'reservation';
update audit_log set at = now() - interval '13 months' where list_id = :'vliste' and action = 'created' and kind = 'list';
select audit_purge();
select pg_temp.pruefe((select count(*) from audit_log where list_id = :'vliste' and (kind = 'reservation' or (kind = 'list' and action = 'created'))) = 0
  and (select count(*) from audit_log where list_id = :'vliste') > 0, 'Aufräumen löscht genau das Abgelaufene');


-- Kontoarten: Familie darf Listen anlegen, Schenkende nicht
select pg_temp.als(null);
select pg_temp.pruefe((select account_type from profiles where id = '11111111-1111-1111-1111-111111111111') = 'family'
  and (select account_type from profiles where id = '33333333-3333-3333-3333-333333333333') = 'guest', 'Kontoart kommt aus der Freischaltung');
select pg_temp.als('33333333-3333-3333-3333-333333333333');
do $$ begin perform create_list('Darf nicht'); raise exception 'FEHLGESCHLAGEN: Schenkendenkonto hat eine Liste angelegt';
  exception when insufficient_privilege then raise notice 'OK: Schenkendenkonten können keine Listen anlegen'; end $$;
-- Selbst registriert und freigegeben: standardmäßig Schenkender
select pg_temp.als(null);
set role service_role;
delete from rate_events where bucket like 'access:%';
select request_access('selbst@test.de', '9.9.9.9') is not null as x \gset
select request_access('familie@test.de', '9.9.9.8') is not null as x \gset
reset role;
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select decide_access((select id from pending_access_requests() where email = 'selbst@test.de'), true) is not null as x \gset
select decide_access((select id from pending_access_requests() where email = 'familie@test.de'), true, 'family') is not null as x \gset
select pg_temp.als(null);
insert into auth.users values ('66666666-6666-6666-6666-666666666666', 'selbst@test.de'), ('77777777-7777-7777-7777-777777777777', 'familie@test.de');
select pg_temp.pruefe((select account_type from profiles where id = '66666666-6666-6666-6666-666666666666') = 'guest', 'Freigabe ohne Auswahl ergibt ein Schenkendenkonto');
select pg_temp.pruefe((select account_type from profiles where id = '77777777-7777-7777-7777-777777777777') = 'family', 'Freigabe als Familie ergibt ein Familienkonto');
-- Einladung zum Mitbearbeiten durch einen Administrator: Familienkonto
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select allow_email('partner@test.de') is not null as x \gset
select pg_temp.als(null);
insert into auth.users values ('88888888-8888-8888-8888-888888888888', 'partner@test.de');
select pg_temp.pruefe((select account_type from profiles where id = '88888888-8888-8888-8888-888888888888') = 'family', 'Eingeladene Mitbearbeiter bekommen ein Familienkonto');
-- Umstellen nur durch Administratoren, mit Eintrag im Sicherheitsprotokoll
select pg_temp.als('22222222-2222-2222-2222-222222222222');
do $$ begin perform set_account_type('66666666-6666-6666-6666-666666666666', 'family'); raise exception 'FEHLGESCHLAGEN: Nicht-Admin stellt um';
  exception when insufficient_privilege then raise notice 'OK: Nur Administratoren stellen Kontoarten um'; end $$;
do $$ begin perform list_accounts(); raise exception 'FEHLGESCHLAGEN: Nicht-Admin sieht Konten';
  exception when insufficient_privilege then raise notice 'OK: Nur Administratoren sehen alle Konten'; end $$;
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select set_account_type('66666666-6666-6666-6666-666666666666', 'family');
select pg_temp.pruefe((select account_type from list_accounts() where email = 'selbst@test.de') = 'family', 'Administratorin stellt ein Konto auf Familie um');
select pg_temp.pruefe((select count(*) from audit_log where kind = 'access' and action = 'type_changed' and data->>'type' = 'family') >= 1, 'Umstellung steht im Sicherheitsprotokoll');
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.pruefe((create_list('Jetzt erlaubt')).id is not null, 'Nach der Umstellung darf das Konto Listen anlegen');
select pg_temp.als(null);


-- Konten zum Schenken: Listen am Konto, Reservierungen am Konto
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select id as sliste, guest_token as sgast from create_list('Schenktest', 'Emma') \gset
insert into wishes (list_id, title, quantity, created_by) values (:'sliste', 'Puzzle', 3, auth.uid());
select id as puzzle from wishes where title = 'Puzzle' and list_id = :'sliste' \gset
-- Tobias (Konto zum Schenken) öffnet den Link angemeldet
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.als(null);
update profiles set account_type = 'guest', display_name = 'Tobias' where id = '66666666-6666-6666-6666-666666666666';
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.pruefe(follow_list(:'sgast') = :'sliste'::uuid, 'Link öffnen speichert die Liste am Konto');
select pg_temp.pruefe((select count(*) from my_followed_lists() where list_id = :'sliste') = 1, 'Gespeicherte Liste erscheint in der Übersicht');
select pg_temp.pruefe((select count(*) from lists where id = :'sliste') = 0 and (select count(*) from wishes where list_id = :'sliste') = 0
  and (select count(*) from reservations) = 0, 'Gespeichert heißt nicht Mitglied: keine Tabellen-Einsicht');
-- Reservieren angemeldet über die Gästefunktion: gehört dem Konto, Aufheben ohne Code
select pg_temp.als(null);
delete from rate_events;
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select reserve_wish(:'sgast', :'puzzle', 1, 'Tobias')->>'code' as tcode \gset
select pg_temp.pruefe((select count(*) from my_account_reservations(:'sgast')) = 1, 'Angemeldete Reservierung gehört dem Konto');
select id as tres from my_account_reservations(:'sgast') limit 1 \gset
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe(not cancel_my_reservation(:'tres'), 'Fremde können eine Konto-Reservierung nicht aufheben');
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.pruefe(cancel_my_reservation(:'tres'), 'Konto hebt eigene Reservierung ohne Code auf');
-- Code von früher (ohne Anmeldung reserviert) dem Konto zuordnen, auch in anderer Schreibweise
select pg_temp.als('anon');
select reserve_wish(:'sgast', :'puzzle', 1, 'Tobias')->>'code' as altcode \gset
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.pruefe(claim_reservations(array[lower(replace(:'altcode', '-', ''))]) = 1, 'Reservierung vom Gerät wird dem Konto zugeordnet');
select pg_temp.pruefe(claim_reservations(array[:'altcode']) = 0, 'Zuordnung nur einmal');
select pg_temp.als('22222222-2222-2222-2222-222222222222');
select pg_temp.pruefe(claim_reservations(array[:'altcode']) = 0, 'Fremde können eine zugeordnete Reservierung nicht übernehmen');
-- Eltern sehen, wer gespeichert hat, und können hinzufügen und entfernen
select pg_temp.als('11111111-1111-1111-1111-111111111111');
select pg_temp.pruefe((select display_name from list_followers_of(:'sliste')) = 'Tobias', 'Eltern sehen Schenkende mit Konto');
select pg_temp.pruefe(add_follower(:'sliste', 'niemand@test.de')->>'status' = 'no_account', 'Ohne Konto: Hinweis statt Fehler');
select pg_temp.pruefe(add_follower(:'sliste', 'JULIA@test.de')->>'status' = 'member', 'Mitglieder werden nicht zusätzlich gespeichert');
delete from list_followers where list_id = :'sliste' and user_id = '66666666-6666-6666-6666-666666666666';
select pg_temp.pruefe(add_follower(:'sliste', 'selbst@test.de')->>'status' = 'added', 'Eltern fügen ein Konto hinzu');
select pg_temp.pruefe((select string_agg(action, ',' order by id) from audit_log where list_id = :'sliste' and kind = 'member')
  = 'follower_saved,follower_removed,follower_added', 'Speichern, Entfernen und Hinzufügen stehen im Verlauf');
-- Fremde dürfen nichts davon
select pg_temp.als('33333333-3333-3333-3333-333333333333');
do $$ begin perform add_follower((select list_id from list_followers limit 1), 'x@test.de'); raise exception 'FEHLGESCHLAGEN: Fremder fügt hinzu';
  exception when insufficient_privilege then raise notice 'OK: Fremde können keine Konten zu Listen hinzufügen'; end $$;
select pg_temp.pruefe((select count(*) from list_followers) = 0, 'Fremde sehen nicht, wer welche Liste gespeichert hat');
-- Archivierte Listen verschwinden aus der Übersicht
select pg_temp.als('11111111-1111-1111-1111-111111111111');
update lists set archived_at = now() where id = :'sliste';
select pg_temp.als('66666666-6666-6666-6666-666666666666');
select pg_temp.pruefe((select count(*) from my_followed_lists() where list_id = :'sliste') = 0, 'Abgeschlossene Listen erscheinen nicht in der Übersicht');
select pg_temp.als(null);

\echo 'Alle Datenbank-Tests bestanden.'
