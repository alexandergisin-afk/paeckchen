import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
// Schriften werden mit der App ausgeliefert (keine Anfragen an Google, schneller, datenschutzfreundlich)
import "@fontsource/atkinson-hyperlegible/latin-400.css";
import "@fontsource/atkinson-hyperlegible/latin-700.css";
import "@fontsource-variable/bricolage-grotesque/opsz.css";
import "./fonts.css";
import "./styles.css";
import { forgetTextSize } from "./lib/device";
import "./lib/install";
import { captureShareFromLaunch } from "./lib/share";
import { installErrorReporting } from "./lib/errorlog";

installErrorReporting();

captureShareFromLaunch();

// Start vom Startbildschirm (iPhone) mit „?liste=…“: direkt zu dieser Wunschliste
try {
  const liste = new URLSearchParams(window.location.search).get("liste");
  const asApp = window.matchMedia?.("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
  if (liste && asApp && (!window.location.hash || window.location.hash === "#/" || window.location.hash === "#")) window.location.hash = `#/w/${liste}`;
} catch { /* egal */ }

forgetTextSize();

// Abgelaufene oder ungültige Anmeldelinks kommen als #error=… zurück. Das würde den Router verwirren,
// deshalb lesen wir die Meldung vorher aus und räumen die Adresse auf.
let linkError: string | null = null;
const raw = window.location.hash.startsWith("#error") ? window.location.hash.slice(1) : window.location.search.slice(1);
const params = new URLSearchParams(raw);
if (params.get("error")) {
  linkError =
    params.get("error_code") === "otp_expired"
      ? "Dieser Anmeldelink ist abgelaufen oder wurde schon benutzt. Fordere einfach einen neuen an."
      : "Die Anmeldung hat nicht geklappt. Fordere bitte einen neuen Link an.";
  window.history.replaceState(null, "", window.location.pathname + "#/");
}

// Schutz vor „Clickjacking“: Päckli nie in fremden Seiten anzeigen (GitHub Pages erlaubt dafür keine
// Server-Einstellung). Eingebettet erscheint nur ein Hinweis mit Link, der Päckli direkt öffnet.
function isFramed(): boolean {
  try { return window.self !== window.top; } catch { return true; } // Zugriff verweigert: ganz sicher eingebettet
}

createRoot(document.getElementById("root")!).render(
  isFramed() ? (
    <main className="wrap narrow framed">
      <h1>Päckli</h1>
      <p className="lead">Aus Sicherheitsgründen lässt sich Päckli nicht in anderen Seiten anzeigen.</p>
      <a className="btn" href={window.location.href} target="_blank" rel="noopener noreferrer">Päckli direkt öffnen</a>
    </main>
  ) : (
    <StrictMode>
      <App linkError={linkError} />
    </StrictMode>
  ),
);

// Offline-Modus: Service Worker nur in der veröffentlichten Version (nicht beim Entwickeln)
if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => undefined);
  });
}
